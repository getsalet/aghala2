-- Roll back 50 Russian (ru-RU) translations (russian-batch-017-sources-0801-0850)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_520_ci;
SET collation_connection = 'utf8mb4_unicode_520_ci';
USE `navaraby_wp569`;

-- Russian rollback: irr-12
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:irr-12:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-329
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-329:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-299
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-299:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-336
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-336:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-016
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-016:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-297
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-297:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-003
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-003:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-281
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-281:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-233
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-233:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-263
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-263:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-277
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-277:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-300
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-300:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-212
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-212:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-270
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-270:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-210
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-210:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-269
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-269:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-237
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-237:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-284
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-284:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-295
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-295:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-222
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-222:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-285
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-285:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-255
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-255:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-241
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-241:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-140
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-140:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-135
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-135:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-159
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-159:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-184
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-184:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-167
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-167:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-185
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-185:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-149
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-149:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-206
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-206:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-190
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-190:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-179
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-179:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-175
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-175:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-182
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-182:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-196
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-196:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-205
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-205:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-173
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-173:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-193
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-193:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-104
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-104:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-097
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-097:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-054
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-054:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-059
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-059:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-055
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-055:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-072
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-072:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-079
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-079:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-053
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-053:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-098
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-098:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-650
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-650:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-630
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-630:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;

