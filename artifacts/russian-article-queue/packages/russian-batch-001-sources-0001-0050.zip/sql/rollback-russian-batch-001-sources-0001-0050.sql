-- Roll back 50 Russian (ru-RU) translations (russian-batch-001-sources-0001-0050)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_520_ci;
SET collation_connection = 'utf8mb4_unicode_520_ci';
USE `navaraby_wp569`;

-- Russian rollback: crop-050
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-050:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-049
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-049:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-048
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-048:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-047
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-047:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-044
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-044:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-045
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-045:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-046
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-046:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-042
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-042:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-043
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-043:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-041
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-041:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-040
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-040:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-038
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-038:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-037
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-037:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-039
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-039:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-036
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-036:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-032
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-032:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-034
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-034:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-035
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-035:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-031
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-031:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-033
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-033:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-029
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-029:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-030
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-030:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-027
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-027:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-028
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-028:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-023
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-023:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-024
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-024:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-025
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-025:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-026
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-026:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-022
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-022:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-021
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-021:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-020
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-020:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-016
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-016:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-019
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-019:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-018
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-018:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-017
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-017:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-010
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-010:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-014
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-014:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-011
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-011:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-015
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-015:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-013
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-013:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-012
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-012:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-008
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-008:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-009
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-009:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-007
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-007:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-006
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-006:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-005
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-005:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-004
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-004:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-003
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-003:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-002
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-002:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-001
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-001:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;

