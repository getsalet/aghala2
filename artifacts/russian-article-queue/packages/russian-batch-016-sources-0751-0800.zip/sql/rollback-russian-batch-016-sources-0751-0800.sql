-- Roll back 50 Russian (ru-RU) translations (russian-batch-016-sources-0751-0800)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_520_ci;
SET collation_connection = 'utf8mb4_unicode_520_ci';
USE `navaraby_wp569`;

-- Russian rollback: xref-648
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-648:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: crop-051
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:crop-051:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-633
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-633:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-636
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-636:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-645
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-645:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-631
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-631:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-634
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-634:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-643
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-643:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-641
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-641:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-632
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-632:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-639
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-639:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-647
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-647:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-622
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-622:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-627
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-627:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-626
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-626:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-625
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-625:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-616
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-616:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-619
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-619:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-617
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-617:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-624
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-624:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-618
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-618:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-611
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-611:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-614
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-614:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-599
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-599:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-628
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-628:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-621
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-621:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-620
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-620:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-608
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-608:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-601
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-601:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-604
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-604:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-603
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-603:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-595
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-595:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-598
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-598:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-605
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-605:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-607
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-607:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-596
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-596:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-609
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-609:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-594
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-594:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-572
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-572:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-579
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-579:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-577
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-577:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-581
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-581:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-574
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-574:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-575
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-575:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-590
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-590:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-576
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-576:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-580
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-580:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-587
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-587:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-584
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-584:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-588
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-588:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;

