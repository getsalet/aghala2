-- Roll back 50 Russian (ru-RU) translations (russian-batch-007-sources-0301-0350)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_520_ci;
SET collation_connection = 'utf8mb4_unicode_520_ci';
USE `navaraby_wp569`;

-- Russian rollback: xref-008
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-008:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-004
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-004:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-015
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-015:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-010
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-010:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: xref-002
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:xref-002:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-023
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-023:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-019
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-019:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-016
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-016:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-033
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-033:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-017
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-017:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-030
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-030:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-024
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-024:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-031
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-031:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-014
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-014:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-026
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-026:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-020
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-020:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-015
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-015:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-028
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-028:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-029
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-029:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-027
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-027:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-022
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-022:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-013
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-013:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-002
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-002:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-111
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-111:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-012
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-012:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-001
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-001:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-005
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-005:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-006
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-006:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-010
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-010:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-110
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-110:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-112
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-112:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-009
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-009:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-011
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-011:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: strat-004
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:strat-004:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-108
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-108:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-082
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-082:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-103
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-103:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-095
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-095:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-083
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-083:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-091
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-091:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-089
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-089:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-067
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-067:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-075
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-075:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-077
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-077:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-071
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-071:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-079
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-079:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-076
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-076:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-080
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-080:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-068
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-068:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;


-- Russian rollback: prod-065
START TRANSACTION; SET @translation_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_translation_queue_key' AND meta_value='article-translation:prod-065:ru-RU' LIMIT 1); DELETE FROM `ha_term_relationships` WHERE object_id=@translation_id; DELETE FROM `ha_postmeta` WHERE post_id=@translation_id; DELETE FROM `ha_posts` WHERE ID=@translation_id; SET @ru_term=(SELECT t.term_id FROM `ha_terms` t JOIN `ha_term_taxonomy` tt ON tt.term_id=t.term_id WHERE t.slug='ru' AND tt.taxonomy='category' LIMIT 1); UPDATE `ha_term_taxonomy` SET `count`=(SELECT COUNT(*) FROM `ha_term_relationships` r WHERE r.term_taxonomy_id=`ha_term_taxonomy`.term_taxonomy_id) WHERE taxonomy='category' AND term_id=@ru_term; COMMIT;

